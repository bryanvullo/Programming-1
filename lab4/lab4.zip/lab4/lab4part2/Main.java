package lab4part2;

public class Main {
  public static void main(String[] args) {
    UserGroup myGroup = new UserGroup();
    myGroup.addSampleData();
    myGroup.printUsernames();
  }
}
