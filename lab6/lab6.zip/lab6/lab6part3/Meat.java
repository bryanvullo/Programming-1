package lab6part3;

public class Meat extends Food {
  public Meat(String name) {
    super(name);
  }
}
