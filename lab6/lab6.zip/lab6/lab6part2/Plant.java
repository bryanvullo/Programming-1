package lab6part2;

public class Plant extends Food {
  public Plant(String name) {
    super(name);
  }
}
