package lab6part2;

abstract class Carnivore extends Animal {
  public Carnivore(String name, int age) {
    super(name, age);
  }
}
