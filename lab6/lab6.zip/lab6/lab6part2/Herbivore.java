package lab6part2;

abstract class Herbivore extends Animal {
  public Herbivore(String name, int age) {
    super(name, age);
  }
}
