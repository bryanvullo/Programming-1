package lab6part1;

public class Plant extends Food {
  public Plant(String name) {
    super(name);
  }
}
