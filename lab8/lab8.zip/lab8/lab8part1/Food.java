package lab8part1;

public class Food {
  String name;
  public Food(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }
}
