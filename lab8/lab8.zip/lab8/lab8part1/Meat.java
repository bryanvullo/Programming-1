package lab8part1;

public class Meat extends Food {
  public Meat(String name) {
    super(name);
  }
}
