package lab8part3;

public class Bicycle extends Cycle {
  //bicycle is a type of cycle
  public int getWheels() {
    return 2;
  }
}
