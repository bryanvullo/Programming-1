package lab8part3;

public class Bicycle extends Cycle {
  int numberOfWheels = 2;
}
