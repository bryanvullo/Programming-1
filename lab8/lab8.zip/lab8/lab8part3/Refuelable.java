package lab8part3;

interface Refuelable {
  //interface as a vehicle being refuelable is a property of the vehicle
  // rather than a type of vehicle
  // a refuelable isn't necessarily an object
  abstract void refuel();
}
