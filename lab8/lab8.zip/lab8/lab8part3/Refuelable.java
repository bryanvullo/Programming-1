package lab8part3;

public class Refuelable implements Transport {
  public void refuel() {
    System.out.println("the vehicle is now refueled");
  }

  public void load() {}

  public void move() {}

  public void location() {}
}
