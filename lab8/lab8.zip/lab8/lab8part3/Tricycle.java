package lab8part3;

public class Tricycle extends Cycle {
  //tricycle is a type of cycle
  public int getWheels() {
    return 3;
  }
}
