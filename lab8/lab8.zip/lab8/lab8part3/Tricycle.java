package lab8part3;

public class Tricycle extends Cycle {
  int numberOfWheels = 3;
}
