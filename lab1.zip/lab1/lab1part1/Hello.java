public class Hello { // Class declaration
  public static void main(String[] args) { //This is the 'main' method
    System.out.println("Hello World!"); // This prints out "Hello World"
  }
}